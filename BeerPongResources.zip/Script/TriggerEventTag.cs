﻿using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public class TriggerEventTag: MonoBehaviour {
	public string TargetTag = "Player";

	public UnityEvent triggerEnter;
    public UnityEvent triggerExit;

    public UnityEvent DelayTriggerEnter;
    public float EnterDelay;
    public UnityEvent DelayTriggerExit;
    public float ExitDelay;

    void OnTriggerEnter (Collider col) {
		if (col.CompareTag(TargetTag))
		{
			triggerEnter.Invoke();
            Invoke("delayEnterEvent", EnterDelay);
        }
	}

	void OnTriggerExit (Collider col) {
		if (col.CompareTag(TargetTag))
		{
            triggerExit.Invoke();
            Invoke("delayExitEvent", ExitDelay);
        }
	}

    void delayEnterEvent()
    {
        DelayTriggerEnter.Invoke();
    }
    void delayExitEvent()
    {
        DelayTriggerExit.Invoke();
    }

}


