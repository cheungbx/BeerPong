﻿using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine.SceneManagement;
using static System.Net.Mime.MediaTypeNames;
[RequireComponent(typeof(AudioSource))]

public class ScoreMgr : MonoBehaviour
{
    public TMP_Text LevelText;
    public TMP_Text UnlockLevelText;
    public TMP_Text PlayerLifeText;
	public TMP_Text ScoreText;
	public TMP_Text HighScoreText;
    public TMP_Text ContinueText;
    public TMP_Text TimerText;

    public string LifeUnit;
    public string ScoreUnit;
    public int MaxHP = 12;
    public int MaxLevel = 4;
    public bool unLockLevelwoReload = false;
    public bool UseTime = false;
	public bool AddTimeToScore = false;
    public float TimeToScoreRatio = 0.1F;

    public AudioClip ScoreSound;
    public AudioClip HurtSound;
    public AudioClip DieSound;
    public AudioClip UnlockLevelSound;
    public AudioClip HighScoreSound;
    public AudioClip WonSound;
    public AudioClip LostSound;
    public AudioClip NewGameSound;
    public AudioClip ContinueSound;
    public AudioClip QuitSound;


    public GameObject GamePlaying;
    public GameObject GameOver;

    public List<GameObject> GameLevels = new List<GameObject>();
    public List<int> UnlockPoints = new List<int>();
    public List<float> Times = new List<float>();
    public List<UnityEvent> UnlockEvents = new List<UnityEvent>();


    public UnityEvent GameOverEvent;
    public UnityEvent WonEvent;
	public float PostWonDelay = 4F;
	public UnityEvent PostWonEvent;

	public UnityEvent LostEvent;
	public float PostLostDelay = 4F;
	public UnityEvent PostLostEvent;

	AudioSource AS;

    public static int highLevel;
	public static int point;
	public static int unlockPoint;
	public static int score;
	public static int highScore;

    public static int HP;
	public static bool lost;
	public static bool won;
    public static bool timesup;
    public static int level;

    public static float time = 1800F;  // 30 minutes in seconds
    public static bool timerActive;
    public static bool LevelAlreadyUnlocked = false;
    public static bool HighScoreSoundPlayed = false;
    void Start()
    {

        AS = GetComponent<AudioSource>();
        lost = false;
        won = false;
        timesup = false;
        timerActive = UseTime;

        level = PlayerPrefs.GetInt("_level", 1);
        Debug.Log("ScoreMgr loaded _level =" + ScoreMgr.level.ToString());

        highLevel = PlayerPrefs.GetInt("_highLevel", 0);
        highScore = PlayerPrefs.GetInt("_highScore", 0);
        score = PlayerPrefs.GetInt("_score", 0);  // cumulate from scores of previous levels.

        point = 0;

        HP = MaxHP;
        if (GamePlaying) GamePlaying.SetActive(true);

        setLevel();


        updateScore(0);

        if (UseTime)
        {
            time = Times[level - 1];
        }
    }
    void Update()
    {
        if (UseTime && !timesup)
        {
            if (time > 0 && timerActive)
            {
                time -= Time.deltaTime;
                 }
            if (time < 0) time = 0;

            if (TimerText)
            {

                int minutes = Mathf.FloorToInt(time / 60F);
                int seconds = Mathf.FloorToInt(time - minutes * 60);

                TimerText.text = string.Format("{0:0}:{1:00}", minutes, seconds);
            }
            if (time <= 0)  // times up, kill the player
            {    
                timesup = true;
                HP = 0;
                updateHP(-1); 
            }
        }
    }

    public void updateScore(int amount)
	{


		// update score to display on score board
		score += amount;
		Debug.Log("Score  = " + score.ToString());
		if (ScoreText) ScoreText.text = ScoreUnit + " " + score.ToString();
        if (ScoreSound) AS.PlayOneShot(ScoreSound);
        if (score > highScore)
		{
			highScore = score;
            if (HighScoreText) HighScoreText.text = "!!! Highest Score !!!";
            if(!HighScoreSoundPlayed)
                {
                if (HighScoreSound) AS.PlayOneShot(HighScoreSound);
                HighScoreSoundPlayed = true;
            }

        }
        else
            if (HighScoreText) HighScoreText.text = "High Score " + highScore.ToString();

        // update point to track whether player earns enough point to get to next level
        AddPoint(amount);


	}
    // AddPoint is used for games  that do not need to reload when proceeding to the next level
    // i.e. for games that unlocks the next level by controlling some barriers, insteaad of needing to reload the game scene again.
    // for games that need to reload the game scene, use the "updateScore" method.
    public void AddPoint(int pts)
    {
        point += pts;
        Debug.Log("Point  = " + point.ToString());

        if (point >= unlockPoint)
        {


            if (!LevelAlreadyUnlocked)
            {
                if (UnlockLevelText) UnlockLevelText.text = "!!Next Level Unlocked!!";

                if (UnlockLevelSound) AS.PlayOneShot(UnlockLevelSound);
                LevelAlreadyUnlocked = true;
            }
            if (unLockLevelwoReload)
            {
                if (level < MaxLevel)
                    level += 1;
                else
                    level = 1;
                point = 0;
                setLevel();
            }
        }
        else
            if (UnlockLevelText) UnlockLevelText.text = (unlockPoint - point).ToString() + " Points to Next Level";

 
    }
    public void updateHP(int amount)
    {
        if (HP <= 0)
		{
			if (point >= unlockPoint)
			{
                won = true;
                if (level < MaxLevel)
                    level += 1;
                else
                    level = 1;
            }
			else
			{
                if (DieSound) AS.PlayOneShot(DieSound);
                lost = true;
			}


            ShowResult();
        }
		else
		{
            HP += amount;
            Debug.Log("HP  = " + HP.ToString());
            if (PlayerLifeText) PlayerLifeText.text = LifeUnit + " " + HP.ToString();
            if (DieSound) AS.PlayOneShot(DieSound);
        }
    
    }
    

	public void setLevel()
    {
        LevelAlreadyUnlocked = false;
        if (LevelText) LevelText.text = "Level " + level.ToString();
		for (int i = 0; i < GameLevels.Count; i++)
		{
			if (i+1 == level)
			{
				GameLevels[i].SetActive(true);
				unlockPoint = UnlockPoints[i];
				UnlockEvents[i].Invoke();
                Debug.Log("Level " + (i+1).ToString() + " unlocked");
            }
            else
				GameLevels[i].SetActive(false);
		}

    }



	public void ShowResult()
	{
        timerActive = false;
        
		if (GamePlaying) GamePlaying.SetActive(false);
		if (GameOver) GameOver.SetActive(true);
        for (int i = 0; i < GameLevels.Count; i++)
            GameLevels[i].SetActive(false);

		if (level > highLevel) highLevel = level;

        if (won && AddTimeToScore)
        {
            score += (int)(time * TimeToScoreRatio);
        }

        if (ScoreText) ScoreText.text = "Score " + score.ToString();
		if (score >= highScore)
		{
			highScore = score;
            if (HighScoreText) HighScoreText.text = "!!! Highest Score !!!";
		}
		else
            if (HighScoreText) HighScoreText.text = "High Score " + highScore.ToString();


		PlayerPrefs.SetInt("_level", level);
		PlayerPrefs.SetInt("_highLevel", highLevel);
		PlayerPrefs.SetInt("_highScore", highScore);
		PlayerPrefs.Save();

        GameOverEvent.Invoke();

        if (won)
		{
            PlayerPrefs.SetInt("_score", score);
            if (PlayerLifeText) PlayerLifeText.text = "You Won";
			ContinueText.text = "Next Level";
			WonEvent.Invoke();
			if (WonSound)
				AS.PlayOneShot(WonSound);
			Invoke("delayInvoke", PostWonDelay);
		}
		else
		{
			if (PlayerLifeText) PlayerLifeText.text = "Game Over";
            ContinueText.text = "Try Again";
            LostEvent.Invoke();
			if (LostSound)
				AS.PlayOneShot(LostSound);
			Invoke("delayInvoke", PostLostDelay);
		}
	}


    public void delayInvoke()
    {
		if (won)
            PostWonEvent.Invoke();
		else
            PostLostEvent.Invoke();
    }


    public void NewGame()
	{
		if (GameOver) GameOver.SetActive(false);
		if (NewGameSound) AS.PlayOneShot(NewGameSound);
        PlayerPrefs.SetInt("_score", 0);
        PlayerPrefs.SetInt("_level", 1);
        Invoke("ReloadGame", 3F);
	}

    public void Continue()
    {
        if (GameOver) GameOver.SetActive(false);
        if (ContinueSound) AS.PlayOneShot(ContinueSound);
        Invoke("ReloadGame", 2F);
    }

    public void Quit()
	{
		if (GameOver) GameOver.SetActive(false);
		if (QuitSound) AS.PlayOneShot(QuitSound);
		Invoke("QuitApp", 2F);
	}


    void ReloadGame()
    {	
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    void QuitApp()
	{
	UnityEngine.Application.Quit();
	}

}


